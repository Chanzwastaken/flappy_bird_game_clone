enum BirdMovement { middle, up, down }
